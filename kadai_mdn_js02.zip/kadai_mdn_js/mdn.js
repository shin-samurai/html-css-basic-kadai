let dtNow = new Date();

let today = dtNow.getFullYear() + "年" + (dtNow.getMonth() + 1) + "月"　+ dtNow.getDate() + "日"　+ dtNow.getHours() + "時" + dtNow.getMinutes() + "分";  

console.log(today);
