const addBtn = document.getElementById('btn');

const msg = document.getElementById('text');


addBtn.addEventListener('click', () => {
  
  msg.textContent = '書き換えました';

  console.log(msg);
  });