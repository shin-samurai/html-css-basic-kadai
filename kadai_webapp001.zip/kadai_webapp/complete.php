<!DOCTYPE html>
<html lang="ja">

<head>
    <meta charset="UTF-8">
    <title>PHP基礎編</title>
</head>

<body>
    <h2>社員情報は確かに受理いたしました。</h2>
    <p>データベースで管理します。</p>
    <button id="back-btn" onclick="location.href='form.php';">戻る</button>
</body>

</html>


<!DOCTYPE html>
<html lang="ja">

<head>
    <meta charset="UTF-8">
    <title>PHP基礎編</title>
</head>

<body>
    <h2>お問い合わせを承りました。</h2>
    <p>ありがとうございました。今後の参考にさせていただきます。</p>
    <button id="back-btn" onclick="location.href='form.php';">戻る</button>
</body>

</html>