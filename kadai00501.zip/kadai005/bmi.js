const bmiTall = 1.7;
const bmiWei = 68.0;
let bmi = bmiWei / (bmiTall*bmiTall);

console.log(bmi);