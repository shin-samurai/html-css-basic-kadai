var dateNow = new Date();
console.log(dateNow);