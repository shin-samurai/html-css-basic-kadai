const dbl = (num) => {
    return num ** 2;
}
    console.log(dbl(10));
