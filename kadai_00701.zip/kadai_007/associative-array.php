<!DOCTYPE html>
<html lang="ja">

<head>
   <meta charset="UTF-8">
   <title>連想配列</title>
</head>

<body>   
  <p>
       <?php
       $asso_array = ["name" => "onion", "price" =>"200", "weight" => "160"];
       echo "<br>";
       print_r($asso_array);
       ?>
   </p>
</body>

</html>