const dbl = (num) => {
    return num * 10;
}
    console.log(dbl(10));
